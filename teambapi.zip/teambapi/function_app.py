import azure.functions as func
from get_weather import get_today_weather
from get_forecast import get_forecast
from get_predict import predict_all
from get_today import get2day
from get_forecast import getfcst
app = func.FunctionApp(http_auth_level=func.AuthLevel.ANONYMOUS)

@app.route(route="gettodayowm")
def get_today_weather(req: func.HttpRequest) -> func.HttpResponse:
    return get2day(req)

@app.route(route="getforecast")
def get_forecast_weather(req: func.HttpRequest) -> func.HttpResponse:
    return getfcst(req)

# @app.route(route="getpredict")
# def get_predict_sales(req: func.HttpRequest) -> func.HttpResponse:
#     return predict_all(req)
