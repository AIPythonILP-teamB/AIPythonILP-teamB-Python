import os
import json
import joblib
import pandas as pd
import azure.functions as func

# モデルの読み込み
MODEL_DIR = "models"
MODEL_FILES = {
    "ipa": "IPA.pkl",
    "lager": "lager.pkl",
    "pale_ale": "pale_ale.pkl",
    "dark_beer": "dark_beer.pkl",
    "furit_beer": "furit_beer.pkl",
    "white_beer": "white_beer.pkl"
}

# モデルを一括読み込み
models = {}
for name, file in MODEL_FILES.items():
    path = os.path.join(MODEL_DIR, file)
    if os.path.exists(path):
        models[name] = joblib.load(path)
    else:
        raise FileNotFoundError(f"モデルファイルが見つかりません: {path}")

def run_prediction(req: func.HttpRequest) -> func.HttpResponse:
    try:
        data = req.get_json()  # get_forecast.pyから渡される天気予報JSON

        if not isinstance(data, list) or len(data) == 0:
            return func.HttpResponse("無効な入力データ", status_code=400)

        # 入力をDataFrame化
        df = pd.DataFrame(data)

        # 必要な列だけ抽出（ここはトレーニング時の特徴量と一致させてください）
        selected_features = [
            '祝日前日フラグ', '降水量の合計(mm)', '1時間降水量の最大(mm)',
            '気温差', '日照時間(時間)', '平均気温(℃)',
            '曜日_月', '曜日_金', '月', '平均湿度(％)'
        ]
        if not all(col in df.columns for col in selected_features):
            return func.HttpResponse("必要な特徴量が不足しています", status_code=400)

        X = df[selected_features]

        # モデルごとに予測
        predictions = []
        for i in range(len(X)):
            daily_result = {"date": df.iloc[i]["date"]}
            for beer_type, model in models.items():
                y_pred = model.predict([X.iloc[i].values])[0]
                daily_result[f"{beer_type}_pred"] = round(y_pred, 2)
            predictions.append(daily_result)

        # return func.HttpResponse(json.dumps(predictions, ensure_ascii=False), mimetype="application/json")
        return predictions

    except Exception as e:
        return func.HttpResponse(f"予測中にエラーが発生しました: {str(e)}", status_code=500)
