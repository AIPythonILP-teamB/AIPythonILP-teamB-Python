import azure.functions as func
import requests
import datetime
import os
import json

# app = func.FunctionApp()

# @app.route(route="gettodayowm")
def get2day(req: func.HttpRequest) -> func.HttpResponse:
    api_key = os.environ.get("OWM_API_KEY")
    city = req.params.get("city", "Tokyo")
    if not api_key:
        return func.HttpResponse("Missing OWM_API_KEY", status_code=500)

    url = "https://api.openweathermap.org/data/2.5/forecast"
    params = {
        "q": city,
        "appid": api_key,
        "units": "metric",
        "lang": "en"
    }

    res = requests.get(url, params=params)
    if res.status_code != 200:
        return func.HttpResponse("Error fetching weather", status_code=500)

    data = res.json()
    today = datetime.date.today().isoformat()


    today_entries = [item for item in data["list"] if item["dt_txt"].startswith(today)]
    if not today_entries:
        return func.HttpResponse("今日の天気データが見つかりませんでした", status_code=404)

    max_temp = max(e["main"]["temp_max"] for e in today_entries)
    min_temp = min(e["main"]["temp_min"] for e in today_entries)
    wind_speed = round(sum(e["wind"]["speed"] for e in today_entries) / len(today_entries), 1)
    main_weather = today_entries[0]["weather"][0]["main"]
    icon_code = today_entries[0]["weather"][0]["icon"]
    icon_url = f"https://openweathermap.org/img/wn/{icon_code}@2x.png"

    result = {
        "date": today,
        "weatherMain": main_weather,
        "maxTemp": round(max_temp, 1),
        "minTemp": round(min_temp, 1),
        "windSpeed": wind_speed,
        "icon": icon_code,
        "iconUrl": icon_url
    }

    return func.HttpResponse(json.dumps(result, ensure_ascii=False), mimetype="application/json")
