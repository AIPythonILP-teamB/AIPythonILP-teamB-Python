import azure.functions as func
import requests
import datetime
from collections import defaultdict
import json
from get_predict import run_prediction

# 補助関数
def mean(values):
    return round(sum(values) / len(values), 1) if values else None

def sun_hours(values):
    return round(sum(values) / 3600, 1) if values else None

def group_hourly_by_day(times, data):
    grouped = defaultdict(list)
    for t, v in zip(times, data):
        date = t.split("T")[0]
        grouped[date].append(v)
    return grouped

# @app.route(route="get_forecast")
def getfcst(req: func.HttpRequest) -> func.HttpResponse:
    city = req.params.get("city", "Tokyo")

    city_coords = {
        "Tokyo": (35.69, 139.69),
        # "Osaka": (34.69, 135.50),
        # "Sapporo": (43.06, 141.35)
    }

    if city not in city_coords:
        return func.HttpResponse("City not supported", status_code=400)

    lat, lon = city_coords[city]

    url = "https://api.open-meteo.com/v1/forecast"
    params = {
        "latitude": lat,
        "longitude": lon,
        "daily": "temperature_2m_max,temperature_2m_min,precipitation_sum,weathercode",
        "hourly": "relative_humidity_2m,sunshine_duration,windspeed_10m,vapour_pressure_deficit",
        "timezone": "Asia/Tokyo"
    }

    res = requests.get(url, params=params)
    if res.status_code != 200:
        return func.HttpResponse("Open-Meteo error", status_code=500)

    data = res.json()
    daily = data.get("daily", {})
    hourly = data.get("hourly", {})
    times = hourly.get("time", [])

    humidity_by_day = group_hourly_by_day(times, hourly.get("relative_humidity_2m", []))
    sunshine_by_day = group_hourly_by_day(times, hourly.get("sunshine_duration", []))
    windspeed_by_day = group_hourly_by_day(times, hourly.get("windspeed_10m", []))
    vapour_by_day = group_hourly_by_day(times, hourly.get("vapour_pressure_deficit", []))
    precip_by_day = group_hourly_by_day(times, hourly.get("precipitation", [])) 

    result = []
    for i, date in enumerate(daily["time"][1:8]): 
        dt = datetime.datetime.strptime(date, "%Y-%m-%d")
        weekday = dt.weekday()  # 0=月曜, 4=金曜
        month = dt.month

        result.append({
            "date": date,
            "祝日前日フラグ": 0,
            "降水量の合計(mm)": daily["precipitation_sum"][i + 1],
            "1時間降水量の最大(mm)": max(precip_by_day.get(date, []), default=None),
            "気温差": round(daily["temperature_2m_max"][i + 1] - daily["temperature_2m_min"][i + 1], 1),
            "日照時間(時間)": sun_hours(sunshine_by_day.get(date, [])),
            "平均気温(℃)": round((daily["temperature_2m_max"][i + 1] + daily["temperature_2m_min"][i + 1]) / 2, 1),
            "曜日_月": 1 if weekday == 0 else 0,
            "曜日_金": 1 if weekday == 4 else 0,
            "月": month,
            "平均湿度(％)": mean(humidity_by_day.get(date, []))
        })

    # return func.HttpResponse(json.dumps(result, ensure_ascii=False), mimetype="application/json")
    try:
        predictions = run_prediction(result)  
    except Exception as e:
        return func.HttpResponse(f"Prediction error: {str(e)}", status_code=500)

    
    return func.HttpResponse(
        json.dumps({
            "weather_forecast": result,
            "prediction_result": predictions
        }, ensure_ascii=False),
        mimetype="application/json"
    )