import pandas as pd
import joblib
import os

model_dir = os.path.join(os.path.dirname(__file__), "..", "models")

model_features = {
    "ipa": ["祝日前日フラグ", "降水量の合計(mm)", "1時間降水量の最大(mm)",
        "気温差", "日照時間(時間)", "平均気温(℃)",
        "曜日_月", "曜日_金","月","平均湿度(％)"],
    "lager": ["祝日前日フラグ", "降水量の合計(mm)", "1時間降水量の最大(mm)",
        "気温差", "日照時間(時間)", "平均気温(℃)",
        "曜日_月", "曜日_金","月","平均湿度(％)"],
    "pale_ale": ["祝日前日フラグ", "降水量の合計(mm)", "1時間降水量の最大(mm)",
        "気温差", "日照時間(時間)", "平均気温(℃)",
        "曜日_月", "曜日_金","月","平均湿度(％)"],
    "dark_beer": ["祝日前日フラグ", "降水量の合計(mm)", "1時間降水量の最大(mm)",
        "気温差", "日照時間(時間)", "平均気温(℃)",
        "曜日_月", "曜日_金","月","平均湿度(％)"],
    "fruit_beer": ["祝日前日フラグ", "降水量の合計(mm)", "1時間降水量の最大(mm)",
        "気温差", "日照時間(時間)", "平均気温(℃)",
        "曜日_月", "曜日_金","月","平均湿度(％)"],
    "white_beer": ["祝日前日フラグ", "降水量の合計(mm)", "1時間降水量の最大(mm)",
        "気温差", "日照時間(時間)", "平均気温(℃)",
        "曜日_月", "曜日_金","月","平均湿度(％)"]
}

def run_prediction(data):
    df = pd.DataFrame(data)
    predictions = []

    models = {
        "ipa": joblib.load(os.path.join(model_dir, "IPA.pkl")),
        "lager": joblib.load(os.path.join(model_dir, "lager.pkl")),
        "pale_ale": joblib.load(os.path.join(model_dir, "pale_ale.pkl")),
        "dark_beer": joblib.load(os.path.join(model_dir, "dark_beer.pkl")),
        "fruit_beer": joblib.load(os.path.join(model_dir, "furit_beer.pkl")),
        "white_beer": joblib.load(os.path.join(model_dir, "white_beer.pkl")),
    }

    for _, row in df.iterrows():
        row_result = {"date": row["date"]}
        total = 0
        for beer, model in models.items():
            feature_cols = model_features[beer]

        
            missing = [col for col in feature_cols if col not in row]
            if missing:
                raise ValueError(f"Missing features for {beer}: {missing}")

            X = row[feature_cols].values.reshape(1, -1)
            y_pred = model.predict(X)[0]
            row_result[beer] = round(y_pred, 2)
            total += y_pred
        
        row_result["total_prediction"] = round(total, 2)
        predictions.append(row_result)

    return predictions

# model_dir = os.path.join(os.path.dirname(__file__), "..", "models")

# def run_prediction(data):
#     df = pd.DataFrame(data)
#     predictions = []

#     models = {
#         "ipa": "IPA.pkl",
#         "lager": "lager.pkl",
#         "pale_ale": "pale_ale.pkl",
#         "dark_beer": "dark_beer.pkl",
#         "fruit_beer": "furit_beer.pkl",
#         "white_beer": "white_beer.pkl"
#     }

#     loaded = {k: joblib.load(os.path.join(model_dir, v)) for k, v in models.items()}

#     for _, row in df.iterrows():
#         row_result = {}
#         for beer, model in loaded.items():
#             row_result[beer] = round(model.predict([row.values])[0], 2)
#         predictions.append(row_result)

#     return predictions
