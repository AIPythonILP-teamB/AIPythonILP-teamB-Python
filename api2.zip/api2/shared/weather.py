import requests
from collections import defaultdict
import datetime
 
def get_forecast_data(city="Tokyo"):
    lat, lon = (35.69, 139.69)
    url = "https://api.open-meteo.com/v1/forecast"
    params = {
        "latitude": lat,
        "longitude": lon,
        "daily": "temperature_2m_max,temperature_2m_min,precipitation_sum,weathercode",
        "hourly": "relative_humidity_2m,sunshine_duration,windspeed_10m,vapour_pressure_deficit,precipitation",
        "timezone": "Asia/Tokyo"
    }
 
    res = requests.get(url, params=params)
    data = res.json()
 
    daily = data["daily"]
    hourly = data["hourly"]
    times = hourly["time"]
 
    def group(key):
        g = defaultdict(list)
        for t, v in zip(times, hourly[key]):
            g[t.split("T")[0]].append(v)
        return g
    precip_hourly = group("precipitation")
    hum = group("relative_humidity_2m")
    sun = group("sunshine_duration")
    wind = group("windspeed_10m")
    vapour = group("vapour_pressure_deficit")
 
    def mean(x): return round(sum(x)/len(x), 1) if x else None
    def sun_hr(x): return round(sum(x)/3600, 1) if x else None
    icon_map = {
        0: "01d", 1: "02d", 2: "02d", 3: "03d",
        45: "50d", 48: "50d",
        51: "09d", 53: "09d", 55: "09d",
        61: "10d", 63: "10d", 65: "10d",
        71: "13d", 73: "13d", 75: "13d",
        95: "11d", 96: "11d", 99: "11d"
    }
    result = []
    for i, date in enumerate(daily["time"][1:9]):
        dt = datetime.datetime.strptime(date, "%Y-%m-%d")
        if dt.weekday() == 6:
            continue
        
        wcode = daily["weathercode"][i + 1]
        icon_code = icon_map.get(wcode, "01d")
        icon_url = f"https://openweathermap.org/img/wn/{icon_code}@2x.png"

        result.append({
            "date": date,
            "祝日前日フラグ": 0,
            "降水量の合計(mm)": daily["precipitation_sum"][i + 1],
            "1時間降水量の最大(mm)": max(precip_hourly[date], default=0),
            "平均気温(℃)": round((daily["temperature_2m_max"][i + 1] + daily["temperature_2m_min"][i + 1]) / 2, 1),
            "最高気温(℃)": daily["temperature_2m_max"][i + 1],
            "最低気温(℃)": daily["temperature_2m_min"][i + 1],
            "気温差": round(daily["temperature_2m_max"][i + 1] - daily["temperature_2m_min"][i + 1], 1),
            "日照時間(時間)": sun_hr(sun[date]),
            
            "曜日_月": 1 if dt.weekday() == 0 else 0,
            "曜日_金": 1 if dt.weekday() == 4 else 0,
            "月": dt.month,
            "平均湿度(％)": mean(hum[date]),
            "天気アイコン": icon_url
        })
 
    return result