import azure.functions as func
import requests
import datetime
from collections import defaultdict
import json
import os
import json

from shared.weather import get_forecast_data

def main(req: func.HttpRequest) -> func.HttpResponse:
    result = get_forecast_data()
    return func.HttpResponse(json.dumps(result, ensure_ascii=False), mimetype="application/json")
