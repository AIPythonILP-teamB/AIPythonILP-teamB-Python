import azure.functions as func
import json
from shared.weather import get_forecast_data
from shared.predict import run_prediction

import requests
import datetime
from collections import defaultdict
import os
def main(req: func.HttpRequest) -> func.HttpResponse:
    try:
        forecast = get_forecast_data()
        prediction_results = run_prediction(forecast)

        combined = []
        for weather, pred in zip(forecast, prediction_results):
            combined.append({
                "date": weather["date"],
                "weather": weather,
                "prediction": pred
            })

        return func.HttpResponse(json.dumps(combined, ensure_ascii=False), mimetype="application/json")

    except Exception as e:
        return func.HttpResponse(f" Error: {str(e)}", status_code=500)
#9.00

# def main(req: func.HttpRequest) -> func.HttpResponse:
    
    
#     forecast = get_forecast_data()

    
#     prediction_results = run_prediction(forecast)

    
#     combined = []
#     for weather, pred in zip(forecast, prediction_results):
#         combined.append({
#             "date": weather["date"],
#             "weather": weather,
#             "prediction": pred
#         })

#     return func.HttpResponse(json.dumps(combined, ensure_ascii=False), mimetype="application/json")
